# HeltecPT100Kit v0.2.2 — student-controlled five-stage API

For Heltec WiFi LoRa 32 V4 + MAX31865 + 2-wire PT100. Student functions invoke these library methods:

```cpp
station.beginBoard("TEAM-A", true); // first, starts board and OLED
station.setupPT100();                // initialize SPI and RTD
station.setupLoRa();                 // initialize radio (attach antenna!)
station.setupAP("Classroom2026");   // captive portal + Wi-Fi AP

// in loop() (call frequently):
station.update();                    // services Wi-Fi, OLED, LoRa reception/relay
station.readTemp();                  // nonblocking sensor state machine
// on a student-chosen schedule, e.g. every 12 seconds:
station.broadcastTemp();             // best-effort radio packet; returns bool
```

`local()`, `peerCount()`, `peer()`, `wifiName()`, `wifiIP()`, and `showMessage()` provide readable student access to sensor data, remote nodes, and OLED messages. `broadcastTemp()` sends an invalid/fault packet if the last completed sensor reading is bad; never treats a fault as a true 0°C temperature.

Legacy `station.begin(name, password, relay)` remains available to older sketches and retains automatic sampling/transmit behavior. New classroom `beginBoard()` path does **not** auto sample or auto broadcast.

This library includes the MAX31865 driver, OLED, captive portal (HTTP + wildcard DNS), calibration API and raw LoRa with one-hop forwarding; it is not a full mesh or Internet connection. Use compatible regional LoRa bands/antennas and non-identifying station labels. Only one `Station` instance is supported.

**Preflight:** Match Heltec V4 board support with `LoRaWan_APP.h`, `HT_SSD1306Wire.h`, and `driver/board-config.h`. Compile and test on actual hardware before class.

## Transmit pacing (v0.2.2)

Local and relayed packets are protected by the same `radioCanTransmit()` check. `radioTxActive` blocks overlap until TxDone/TxTimeout, after which a 1500 ms nonblocking cooldown starts. Student code should still use its own much longer interval (default 12000 ms) for class traffic.


## Uprooted HTML API (v0.2.2)

The student sketch includes `website.h`, which contains a `const char STUDENT_HTML[] PROGMEM` raw HTML string.
Students edit the HTML inside that file. Call `station.beginBoard()` (no name required), then
`station.setupAP(WIFI_PASSWORD, STUDENT_HTML)` to serve the student page at `/`.
The temperature JSON remains at `/api/status`, other nodes at `/api/nodes`.
The access point is automatically named `PT100-UPROOTED-XXXX`, based on the chip's ID.
`station.setupAP(password)` is still available for legacy sketches and serves the original dashboard.
Recompile/upload after changing `website.h`. Do not put raw HTML in the `.ino` file.


## Exit-node fallback (v0.2.3)
If `station.setupPT100()` fails or the MAX31865 later stops responding over
SPI, the board **continues** operating its Wi-Fi AP, captive portal, OLED,
LoRa receiver and one-hop relay. `/api/status` includes `mode: "exit_node"`,
`exit_node: true`, and `sensor_ready: false` while in fallback mode.
Both the supplied student `website.h` and library default page display
**Operating as an exit node** and prioritize online LoRa sensor cards from
`/api/nodes`; no local temperature is fabricated. The board does **not**
provide internet routing. MAX31865 SPI is retried approximately every 2s
when `station.readTemp()` is called, and the page automatically resumes local
sensor mode if SPI recovers. A faulted PT100 with working SPI remains a
sensor station and displays its fault for troubleshooting.
