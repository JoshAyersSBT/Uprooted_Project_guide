#pragma once
#include <Arduino.h>

// Kept outside .ino to prevent Arduino preprocessor from treating
// JavaScript functions as C++ function declarations.
static const char PAGE[] PROGMEM = R"PT100PAGE(
<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Uprooted | Sensor Network</title>
<style>
  :root {color-scheme: dark; font-family: system-ui, -apple-system, Segoe UI, sans-serif;
         background:#0b1220; color:#ecf4ff;}
  *{box-sizing:border-box}
  body{margin:0;min-height:100vh;padding:26px 16px;background:radial-gradient(circle at top,#183454,#0b1220 65%)}
  main{max-width:660px;margin:0 auto}
  header{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:22px}
  h1{margin:0;font-size:clamp(21px,4vw,29px)}
  .sub{color:#9db3cd;font-size:13px;margin:7px 0 0}
  .pill{border:1px solid #607993;border-radius:100px;padding:7px 12px;font-size:12px;white-space:nowrap}
  .ok{color:#75f0b3;border-color:#397d66}.bad{color:#ff9b9b;border-color:#a45858}
  .card{background:rgba(26,42,66,.88);border:1px solid #34516e;border-radius:18px;padding:26px;margin-bottom:14px}
  .overline{font-size:12px;letter-spacing:.16em;color:#a8c0dc;text-transform:uppercase}
  .big{font-size:clamp(62px,13vw,102px);font-weight:750;letter-spacing:-.05em;margin:12px 0}
  .unit{font-size:.38em;color:#a8c0dc;margin-left:8px;letter-spacing:0}
  .grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
  .metric{font-size:27px;font-weight:650;margin:12px 0 0;overflow-wrap:anywhere}
  .foot{color:#94abc7;font-size:13px;line-height:1.7;margin-top:18px}
  #modeBanner{display:none;background:#123e3d;border:1px solid #3e978c;border-radius:14px;
    padding:18px;margin-bottom:14px;line-height:1.6}
  #modeBanner strong{display:block;font-size:19px;color:#7ff3d0}
  .exit-node .sensor-only{display:none}
  .exit-node #fleetSection{border-color:#3e978c;background:#143036}
  .exit-node #fleetSection .overline{font-size:16px;color:#9ceadd}

  .formrow{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px}
  input{flex:1;min-width:130px;max-width:230px;border:1px solid #607993;border-radius:9px;
    background:#101d32;color:#ecf4ff;padding:11px 12px;font-size:16px}
  button{border:1px solid #447da6;background:#205681;color:#fff;border-radius:9px;
    padding:11px 14px;font-weight:600;cursor:pointer}
  button.secondary{border-color:#607993;background:transparent}
  button:disabled{opacity:.55;cursor:wait}
  #calMessage{font-size:13px;line-height:1.5;min-height:1.4em;color:#a8c0dc}
  #faultDetail{color:#ffb3b3;line-height:1.6;min-height:1.5em}
  @media(max-width:440px){.grid{grid-template-columns:1fr}.card{padding:22px}}
</style>
</head>
<body>
<main>
  <header>
    <div><h1>Uprooted Sensor Network</h1><p class="sub">Heltec V4 · PT100 · OLED + LoRa Fleet</p></div>
    <span class="pill" id="status">CONNECTING</span>
  </header>
  <section id="modeBanner" role="status" aria-live="polite">
    <strong>Operating as an exit node</strong>
    MAX31865 unavailable. This board receives and relays LoRa sensor readings and
    makes them available on its local Wi-Fi webpage. It does not provide internet access.
  </section>
  <section class="card sensor-only">
    <div class="overline">Live temperature</div>
    <div class="big"><span id="temperature">--.-</span><span class="unit">°C</span></div>
    <div id="faultDetail" role="status" aria-live="polite">Connecting to sensor...</div>
  </section>
  <div class="grid sensor-only">
    <section class="card"><div class="overline">Uncorrected resistance</div><div class="metric"><span id="measuredResistance">--</span> Ω</div></section>
    <section class="card"><div class="overline">Raw ADC</div><div class="metric" id="raw">--</div></section>
    <section class="card"><div class="overline">Fault register</div><div class="metric" id="fault">--</div></section>
    <section class="card"><div class="overline">Config register</div><div class="metric" id="config">--</div></section>
  </div>
  <section class="card sensor-only">
    <div class="overline">Two-wire calibration</div>
    <p class="foot">Allow the probe to settle beside an accurate reference thermometer.
      Enter the reference temperature to estimate constant extra resistance in the
      two-wire circuit. Do not calibrate if the probe is being warmed by the ESP32,
      your fingers, or another nearby heat source.</p>
    <div class="grid">
      <div><div class="overline">Compensation</div><div class="metric"><span id="compensation">0.000</span> Ω</div></div>
      <div><div class="overline">Corrected resistance</div><div class="metric"><span id="resistance">--</span> Ω</div></div>
    </div>
    <form id="calForm" class="formrow">
      <input id="referenceC" aria-label="Reference temperature in Celsius" type="number" step="0.1" min="-50" max="150" placeholder="Reference °C" required>
      <button id="applyButton" type="submit">Calibrate</button>
      <button class="secondary" id="resetButton" type="button">Reset offset</button>
    </form>
    <p id="calMessage" role="status"></p>
    <p class="foot">Calibration is stored on the Heltec V4 and survives restarts. The
      uncorrected resistance above remains visible for troubleshooting.</p>
  </section>
  <section class="card" id="fleetSection">
    <div class="overline">Remote LoRa sensors</div>
    <p class="foot">Copies of this firmware broadcast PT100 readings over raw LoRa.
    Nearby boards can relay a packet once. No internet or LoRaWAN service required.</p>
    <div class="grid">
      <div><div class="overline">Nodes online</div><div class="metric" id="nodeCount">0</div></div>
      <div><div class="overline">LoRa traffic</div><div class="metric" id="traffic">--</div></div>
    </div>
    <div id="peerList" class="foot" aria-live="polite">Waiting for LoRa sensor broadcasts...</div>
  </section>
  <p class="foot" id="updated">Waiting for first sample...</p>
  <p class="foot" id="network">Wi-Fi access point: Heltec-PT100</p>
  <p class="foot">Updates every second. This access point works without internet.
     Raw readings are shown for diagnostics; invalid measurements are never displayed as temperatures.</p>
</main>
<script>
  const $ = (id) => document.getElementById(id);
  const hex = (n) => '0x' + Number(n).toString(16).toUpperCase().padStart(2,'0');
  const reasons = [[128,'RTD high threshold'],[64,'RTD low threshold'],[32,'REFIN− high'],
    [16,'REFIN− low'],[8,'RTDIN− low'],[4,'Over/under voltage']];
  let busy = false;
  function escaped(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
  async function refreshFleet(){
    try{
      const r=await fetch('/api/nodes',{cache:'no-store'});
      if(!r.ok) throw new Error('HTTP '+r.status);
      const x=await r.json();
      const active=x.peers.filter(p=>p.online);
      $('nodeCount').textContent=active.length;
      $('traffic').textContent=x.rx+' RX · '+x.tx+' TX';
      $('peerList').innerHTML=active.length ? active.map(p=>
        '<div style="padding:10px 0;border-bottom:1px solid #34516e">'+
        '<strong>'+escaped(p.id)+'</strong> · '+(p.online?'ONLINE':'STALE')+
        ' · '+(p.valid ? Number(p.temperature_c).toFixed(2)+' °C' : 'SENSOR FAULT 0x'+Number(p.fault).toString(16).toUpperCase())+
        '<div>RSSI '+Number(p.rssi)+' dBm · '+Number(p.age_s)+'s ago'+
        (p.via_relay?' · via relay':' · direct')+'</div></div>'
      ).join('') : (x.radio_configured ? 'Waiting for LoRa sensor broadcasts...' : 'LoRa radio is not initialized.');
    }catch(err){$('peerList').textContent='Fleet data unavailable: '+err.message;}
  }

  async function refresh(){
    if (busy) return;
    busy = true;
    try{
      const response = await fetch('/api/status', {cache:'no-store'});
      if(!response.ok) throw new Error('HTTP '+response.status);
      const x = await response.json();
      const exitNode = x.mode === 'exit_node';
      document.body.classList.toggle('exit-node', exitNode);
      $('modeBanner').style.display = exitNode ? 'block' : 'none';
      $('status').textContent = exitNode ? 'EXIT NODE' : x.status;
      $('status').className = 'pill '+(exitNode || x.ok?'ok':'bad');
      $('temperature').textContent = x.ok ? Number(x.temperature_c).toFixed(1) : '--.-';
      $('resistance').textContent = x.resistance_ohms === null ? '--' : Number(x.resistance_ohms).toFixed(3);
      $('measuredResistance').textContent = x.measured_resistance_ohms === null ? '--' : Number(x.measured_resistance_ohms).toFixed(3);
      $('compensation').textContent = Number(x.compensation_ohms).toFixed(3);
      $('raw').textContent = x.has_sample ? x.raw : '--';
      $('fault').textContent = x.has_sample ? hex(x.fault) : '--';
      $('config').textContent = x.has_sample ? hex(x.config) : '--';
      const active = reasons.filter(([bit]) => (x.fault & bit) !== 0).map(([, name]) => name);
      $('faultDetail').textContent = x.ok ? 'Sensor reading normal' :
        (active.join(' · ') || (x.status==='SPI ERROR' ? 'MAX31865 communication failed' :
        x.status==='STARTING' ? 'Waiting for the first conversion' : 'Temperature measurement unavailable'));
      $('network').textContent = 'AP '+x.ap_ssid+' · Clients: '+x.ap_clients+' · Dashboard: http://'+x.ap_ip+'/';
      $('updated').textContent = x.has_sample ?
        'Last sample: '+ Math.round((x.uptime_ms - x.sample_ms)/1000) +'s ago' : 'Waiting for first sample...';
    }catch(err){
      $('status').textContent='DISCONNECTED'; $('status').className='pill bad';
      $('temperature').textContent='--.-';
      $('faultDetail').textContent='Cannot reach the Heltec V4 ('+err.message+')';
      $('updated').textContent='Connection lost';
    }finally{busy=false;}
  }
  $('calForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    $('applyButton').disabled = true;
    try {
      const response = await fetch('/api/calibrate', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body:new URLSearchParams({reference_c:$('referenceC').value})
      });
      const result = await response.json();
      $('calMessage').textContent = result.message || 'Unknown response';
      if (response.ok) await refresh();
    } catch (error) {
      $('calMessage').textContent = 'Calibration request failed: ' + error.message;
    } finally { $('applyButton').disabled = false; }
  });
  $('resetButton').addEventListener('click', async () => {
    $('resetButton').disabled = true;
    try {
      const response = await fetch('/api/calibration/reset', {method:'POST'});
      const result = await response.json();
      $('calMessage').textContent = result.message || 'Unknown response';
      if (response.ok) await refresh();
    } catch (error) {
      $('calMessage').textContent = 'Reset failed: ' + error.message;
    } finally { $('resetButton').disabled = false; }
  });
  refresh(); refreshFleet(); setInterval(refresh, 1000); setInterval(refreshFleet, 2000);
</script>
</body>
</html>
)PT100PAGE";
