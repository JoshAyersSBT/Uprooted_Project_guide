#include <Arduino.h>
#include <SPI.h>
#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <math.h>
#include <Preferences.h>
#include <Wire.h>
#include "LoRaWan_APP.h"
#include "HT_SSD1306Wire.h"
#include "driver/board-config.h"
#include "dashboard_html.h"
#include "HeltecPT100Kit.h"
#include <ctype.h>

// Heltec WiFi LoRa 32 V4 (ESP32-S3) + MAX31865 (2-wire PT100)
// Pin assignment is compatible with the common S3R2 V4 and newer S3R8 V4 R8,
// without reusing OLED I2C, LoRa, native USB, or PSRAM pins.
// MAX31865 wires: CLK->GPIO4, SDO->GPIO6, SDI->GPIO47, CS->GPIO48.
// MAX31865 VIN->J3 3V3 (NOT J2 Ve), GND->GND.
// 2-wire board: F+/RTD+ bridged, F-/RTD- bridged, 24 selector set.
// Uses ESP32 Arduino core plus Heltec LoRaWan_APP and OLED libraries.
#if !defined(CONFIG_IDF_TARGET_ESP32S3)
#error "Select the Heltec WiFi LoRa 32 V4 (ESP32-S3) board in Arduino IDE"
#endif

namespace HeltecPT100Kit {

// Student settings live in the sketch. These are the classroom runtime copies.
char stationLabel[13] = "UPROOTED";
char classroomPassword[64] = "";
bool relayAllowed = true;
bool classroomInitialized = false;
const char* customDashboardHTML = nullptr; // Student-owned HTML stored in flash
bool legacyAutomatic = false; // only for Station::begin() backward compatibility
bool sensorInitialized = false;
bool apRoutesRegistered = false;
String oledMessage;
uint32_t oledMessageUntil = 0;

// ---- Wi-Fi access point ----
char AP_SSID[33] = "Heltec-PT100"; // Replaced with unique per-board name during initRadio
const char *AP_PASSWORD = classroomPassword;
WebServer server(80);
DNSServer dnsServer;
const IPAddress AP_IP(192, 168, 4, 1);
const IPAddress AP_SUBNET(255, 255, 255, 0);
constexpr uint16_t DNS_PORT = 53;
uint32_t lastNetworkReportAt = 0;
bool apReady = false;
bool dnsReady = false;

// ---- Heltec V4 header pins -> MAX31865 ----
// J3 pin 15 GPIO4  -> CLK (SPI clock)
// J3 pin 17 GPIO6  <- SDO (SPI MISO)
// J2 pin 13 GPIO47 -> SDI (SPI MOSI)
// J2 pin 14 GPIO48 -> CS  (active low)
// Avoid GPIO8-14 (LoRa), GPIO17-21 (OLED/USB), GPIO33-37 (R8 PSRAM).
constexpr int PIN_SCK = 4;
constexpr int PIN_MISO = 6;
constexpr int PIN_MOSI = 47;
constexpr int PIN_CS = 48;

// PT100, 2-wire board with nominal 430-ohm reference resistor.
// If you accurately measure the Rref out-of-circuit, use that resistance here.
// A previously observed 433.6-ohm in-circuit measurement may be influenced by
// other breakout components; do not blindly substitute it.
constexpr float PT100_R0 = 100.0f;
constexpr float RREF = 430.0f;
// Two-wire correction is a fixed resistance subtracted BEFORE converting to
// temperature. 0.0 is the safe, uncalibrated default.
Preferences calibrationStore;
float leadCompensationOhms = 0.0f;

constexpr uint8_t REG_CONFIG = 0x00;
constexpr uint8_t REG_RTD_MSB = 0x01;
constexpr uint8_t REG_FAULT = 0x07;
constexpr uint8_t CFG_BIAS = 0x80;
constexpr uint8_t CFG_ONESHOT = 0x20;
constexpr uint8_t CFG_CLEAR_FAULT = 0x02;

SPIClass sensorBus(HSPI); // Independent bus; Heltec SX1262 uses the onboard radio SPI.
SPISettings sensorSPI(100000, MSBFIRST, SPI_MODE1);

uint8_t readRegister(uint8_t address) {
  sensorBus.beginTransaction(sensorSPI);
  digitalWrite(PIN_CS, LOW);
  sensorBus.transfer(address & 0x7F);
  uint8_t result = sensorBus.transfer(0xFF);
  digitalWrite(PIN_CS, HIGH);
  sensorBus.endTransaction();
  return result;
}

void writeRegister(uint8_t address, uint8_t value) {
  sensorBus.beginTransaction(sensorSPI);
  digitalWrite(PIN_CS, LOW);
  sensorBus.transfer(address | 0x80);
  sensorBus.transfer(value);
  digitalWrite(PIN_CS, HIGH);
  sensorBus.endTransaction();
}

uint16_t readRTDWord() {
  sensorBus.beginTransaction(sensorSPI);
  digitalWrite(PIN_CS, LOW);
  sensorBus.transfer(REG_RTD_MSB);
  uint16_t word = (uint16_t)sensorBus.transfer(0xFF) << 8;
  word |= sensorBus.transfer(0xFF);
  digitalWrite(PIN_CS, HIGH);
  sensorBus.endTransaction();
  return word;
}

// IEC 60751 Callendar-Van Dusen equation, inverse by binary search.
float pt100Celsius(float resistance) {
  constexpr float A = 3.9083e-3f;
  constexpr float B = -5.775e-7f;
  constexpr float C = -4.183e-12f;
  float lo = -200.0f, hi = 850.0f;
  for (int i = 0; i < 35; ++i) {
    float t = (lo + hi) * 0.5f;
    float ratio = 1.0f + A*t + B*t*t;
    if (t < 0.0f) ratio += C*(t - 100.0f)*t*t*t;
    if (PT100_R0 * ratio < resistance) lo = t;
    else hi = t;
  }
  return (lo + hi) * 0.5f;
}

// Reverse of IEC 60751 for a known reference thermometer temperature.
float pt100ResistanceAtC(float t) {
  constexpr float A = 3.9083e-3f;
  constexpr float B = -5.775e-7f;
  constexpr float C = -4.183e-12f;
  float ratio = 1.0f + A*t + B*t*t;
  if (t < 0.0f) ratio += C*(t - 100.0f)*t*t*t;
  return PT100_R0 * ratio;
}

// ---- Asynchronous acquisition so the website stays responsive ----
enum SensorPhase { IDLE, BIAS_SETTLING, CONVERTING };
SensorPhase phase = IDLE;
bool spiReady = false;
bool haveReading = false;
bool readingValid = false;
float temperatureC = NAN;
float resistanceOhms = NAN;           // compensated (sensor estimate)
float measuredResistanceOhms = NAN;   // uncorrected ADC ratio
float uncalibratedTemperatureC = NAN;
uint16_t rawRTD = 0;
uint8_t faultRegister = 0;
bool rtdFaultFlag = false;
uint8_t lastConfig = 0;
uint32_t phaseStart = 0;
uint32_t lastReadingAt = 0;
uint32_t lastAttemptAt = 0;
uint32_t lastProbeAt = 0;

constexpr uint32_t SAMPLE_INTERVAL_MS = 1000;
constexpr uint32_t BIAS_SETTLE_MS = 100;
constexpr uint32_t CONVERSION_MS = 100; // > 52ms at 60Hz filter
constexpr uint32_t RETRY_INTERVAL_MS = 2000;

bool initializeSensor() {
  writeRegister(REG_CONFIG, CFG_BIAS);
  delay(10);
  const uint8_t readback = readRegister(REG_CONFIG);
  if (readback != CFG_BIAS) {
    spiReady = false;
    readingValid = false;
    haveReading = false;
    writeRegister(REG_CONFIG, 0x00);
    Serial.printf("MAX31865 SPI ERROR: readback 0x%02X (expected 0x80)\n", readback);
    return false;
  }

  // Restore full-range thresholds and 2-wire settings.
  writeRegister(0x03, 0xFF);
  writeRegister(0x04, 0xFF);
  writeRegister(0x05, 0x00);
  writeRegister(0x06, 0x00);
  writeRegister(REG_CONFIG, 0x00);
  spiReady = true;
  haveReading = false;
  readingValid = false;
  phase = IDLE;
  lastAttemptAt = millis() - SAMPLE_INTERVAL_MS;
  Serial.println("MAX31865 SPI OK; Heltec V4 / 2-wire PT100 initialized");
  return true;
}

void pollSensor() {
  const uint32_t now = millis();

  if (!spiReady) {
    if ((uint32_t)(now - lastProbeAt) >= RETRY_INTERVAL_MS) {
      lastProbeAt = now;
      if (initializeSensor()) Serial.println("[ROLE] SENSOR STATION: MAX31865 recovered");
    }
    return;
  }

  if (phase == IDLE) {
    if ((uint32_t)(now - lastAttemptAt) < SAMPLE_INTERVAL_MS) return;
    lastAttemptAt = now;
    writeRegister(REG_CONFIG, CFG_CLEAR_FAULT); // 2-wire; clear fault
    writeRegister(REG_CONFIG, CFG_BIAS);        // turn on excitation
    phase = BIAS_SETTLING;
    phaseStart = now;
    return;
  }

  if (phase == BIAS_SETTLING) {
    if ((uint32_t)(now - phaseStart) < BIAS_SETTLE_MS) return;
    writeRegister(REG_CONFIG, CFG_BIAS | CFG_ONESHOT);
    phase = CONVERTING;
    phaseStart = now;
    return;
  }

  if (phase == CONVERTING) {
    if ((uint32_t)(now - phaseStart) < CONVERSION_MS) return;
    const uint16_t word = readRTDWord();
    rawRTD = word >> 1;
    faultRegister = readRegister(REG_FAULT);
    lastConfig = readRegister(REG_CONFIG);
    writeRegister(REG_CONFIG, 0x00); // bias off until next sample
    phase = IDLE;
    lastReadingAt = now;
    haveReading = true;

    if (lastConfig != CFG_BIAS) {
      spiReady = false;
      haveReading = false;
      readingValid = false;
      lastProbeAt = now;
      Serial.printf("MAX31865 SPI config mismatch: 0x%02X\n", lastConfig);
      return;
    }

    measuredResistanceOhms = (float)rawRTD * RREF / 32768.0f;
    resistanceOhms = measuredResistanceOhms - leadCompensationOhms;
    rtdFaultFlag = (word & 0x01) != 0;
    readingValid = faultRegister == 0 && !rtdFaultFlag && rawRTD != 0
                   && resistanceOhms >= 18.0f && resistanceOhms <= 391.0f;
    temperatureC = readingValid ? pt100Celsius(resistanceOhms) : NAN;
    uncalibratedTemperatureC = readingValid
        ? pt100Celsius(measuredResistanceOhms) : NAN;

    if (readingValid) {
      Serial.printf("PT100: %.2f C corrected | %.2f C raw | measured=%.3f ohms | offset=%.3f ohms | raw=%u\n",
                    temperatureC, uncalibratedTemperatureC,
                    measuredResistanceOhms, leadCompensationOhms, rawRTD);
    } else {
      Serial.printf("PT100 INVALID | raw=%u | fault=0x%02X | cfg=0x%02X\n",
                    rawRTD, faultRegister, lastConfig);
    }
  }
}

// Exit node = no usable local MAX31865 SPI interface. This board can still
// receive/relay LoRa frames and publish their values through the Wi-Fi AP.
// A faulted PT100 on a communicating MAX31865 remains a sensor station so
// students can diagnose its wiring rather than silently hiding the fault.
bool inExitNodeMode() {
  return !sensorInitialized || !spiReady;
}

const char *sensorStatus() {
  if (!spiReady) return "SPI ERROR";
  if (!haveReading) return "STARTING";
  if ((uint32_t)(millis() - lastReadingAt) > 5000) return "STALE";
  if (!readingValid) return "SENSOR FAULT";
  return "OK";
}


// --------------------------- OLED + LoRa fleet ---------------------------
// Heltec OLED: SDA GPIO17, SCL GPIO18, RST GPIO21; uses factory-approved Vext.
SSD1306Wire oled(0x3c, 500000, SDA_OLED, SCL_OLED, GEOMETRY_128_64, RST_OLED);
bool oledReady = false;
uint32_t lastOledDrawAt = 0;

// Raw SX1262 LoRa: identical channel/parameters required on all nodes.
// Set 868000000 ONLY in countries where that band is permitted; US 915 MHz default.
constexpr uint32_t RADIO_FREQ_HZ = 915000000;
constexpr int8_t RADIO_TX_DBM = 14; // conservative start; use proper LoRa antenna!
constexpr uint8_t RADIO_BW = 0;     // 125 kHz
constexpr uint8_t RADIO_SF = 7;
constexpr uint8_t RADIO_CR = 1;     // 4/5
constexpr uint32_t RADIO_REPORT_MS = 12000;
// Minimum quiet time AFTER each actual LoRa transmission finishes. The radio
// TxDone/TxTimeout events start this timer. No blocking delay() is used so
// OLED, AP, temperature samples, and incoming packets keep being serviced.
// This is a classroom pacing safeguard, not a regulatory duty-cycle guarantee.
constexpr uint32_t RADIO_TX_COOLDOWN_MS = 1500;
constexpr uint32_t PEER_ONLINE_MS = 45000;
constexpr uint32_t PEER_RETAIN_MS = 300000;
constexpr size_t MAX_PEERS = 12;

struct Peer {
  bool used = false;
  uint32_t id = 0;
  uint32_t boot = 0;
  uint32_t seq = 0;
  uint32_t seenAt = 0;
  float temp = NAN;
  float ohms = NAN;
  uint8_t fault = 0;
  bool valid = false;
  bool relayed = false;
  int16_t rssi = 0;
  int8_t snr = 0;
};
Peer peers[MAX_PEERS];
RadioEvents_t radioEvents;
bool radioStarted = false;
bool radioTxActive = false;
bool radioNeedsRx = false;
uint32_t radioTxAt = 0;
uint32_t radioNextTxAllowedAt = 0;
uint32_t radioNextLocalAt = 0;
uint32_t nodeId = 0;
uint32_t bootId = 0;
uint32_t packetSeq = 0;
uint32_t radioTxCount = 0;
uint32_t radioRxCount = 0;
uint32_t radioRelayCount = 0;
char rxPacket[110] = {};
uint16_t rxPacketLen = 0;
int16_t rxPacketRSSI = 0;
int8_t rxPacketSNR = 0;
bool rxPending = false;
char relayPacket[110] = {};
bool relayPending = false;
uint32_t relayDueAt = 0;

size_t onlinePeerCount() {
  size_t count = 0;
  for (auto &p : peers) if (p.used && (uint32_t)(millis() - p.seenAt) <= PEER_ONLINE_MS) ++count;
  return count;
}

// Packet v1: T1,idhex,boothex,seq,ttl,tempCentideg,ohmsMilli,fault,valid
// All quantities are bounded and parsed rather than executed.
void handleReceivedPacket() {
  if (!rxPending) return;
  rxPending = false;
  unsigned long id, boot, seq;
  unsigned int ttl, fault, valid;
  long tempCenti, milliOhms;
  int parsed = sscanf(rxPacket, "T1,%lx,%lx,%lu,%u,%ld,%ld,%u,%u",
      &id, &boot, &seq, &ttl, &tempCenti, &milliOhms, &fault, &valid);
  if (parsed != 8 || ttl > 1 || fault > 255 || valid > 1 ||
      tempCenti < -20000 || tempCenti > 85000 ||
      milliOhms < 0 || milliOhms > 400000) {
    Serial.printf("[LORA] discarded malformed packet (%u bytes)\n", rxPacketLen);
    return;
  }
  if ((uint32_t)id == nodeId) return;
  Peer *slot = nullptr;
  for (auto &p : peers) if (p.used && p.id == (uint32_t)id) { slot = &p; break; }
  if (slot && slot->boot == (uint32_t)boot && slot->seq == (uint32_t)seq) return;
  if (!slot) for (auto &p : peers) if (!p.used ||
     (uint32_t)(millis() - p.seenAt) > PEER_RETAIN_MS) { slot = &p; break; }
  if (!slot) {
    slot = &peers[0];
    for (auto &p : peers) if ((uint32_t)(millis()-p.seenAt) >
      (uint32_t)(millis()-slot->seenAt)) slot = &p;
  }
  *slot = Peer{};
  slot->used = true;
  slot->id = (uint32_t)id;
  slot->boot = (uint32_t)boot;
  slot->seq = (uint32_t)seq;
  slot->seenAt = millis();
  slot->temp = (float)tempCenti / 100.0f;
  slot->ohms = (float)milliOhms / 1000.0f;
  slot->fault = (uint8_t)fault;
  slot->valid = valid != 0;
  slot->relayed = ttl == 0;
  slot->rssi = rxPacketRSSI;
  slot->snr = rxPacketSNR;
  radioRxCount++;
  Serial.printf("[LORA] node=%08lX valid=%d T=%.2f C RSSI=%d dBm viaRelay=%d\n",
    id, valid, slot->temp, slot->rssi, slot->relayed);
  if (relayAllowed && ttl == 1 && !relayPending) {
    // One-hop store-and-forward, with deduplication and random jitter.
    snprintf(relayPacket, sizeof(relayPacket),
             "T1,%08lX,%08lX,%lu,0,%ld,%ld,%u,%u",
             id, boot, seq, tempCenti, milliOhms, fault, valid);
    relayPending = true;
    relayDueAt = millis() + 350 + (esp_random() % 1200);
  }
}

void radioOnTxDone() {
  radioTxActive = false;
  radioNextTxAllowedAt = millis() + RADIO_TX_COOLDOWN_MS;
  radioNeedsRx = true;
}
void radioOnTxTimeout() {
  radioTxActive = false;
  radioNextTxAllowedAt = millis() + RADIO_TX_COOLDOWN_MS;
  Radio.Sleep();
  radioNeedsRx = true;
  Serial.println("[LORA] TX timeout");
}
void radioOnRxDone(uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr) {
  Radio.Sleep();
  if (!rxPending && size > 0 && size < sizeof(rxPacket)) {
    memcpy(rxPacket, payload, size);
    rxPacket[size] = '\0';
    rxPacketLen = size;
    rxPacketRSSI = rssi;
    rxPacketSNR = snr;
    rxPending = true;
  }
  radioNeedsRx = true;
}
void radioOnRxTimeout() { radioNeedsRx = true; }
void radioOnRxError() { radioNeedsRx = true; }

void initRadio() {
  radioEvents.TxDone = radioOnTxDone;
  radioEvents.TxTimeout = radioOnTxTimeout;
  radioEvents.RxDone = radioOnRxDone;
  radioEvents.RxTimeout = radioOnRxTimeout;
  radioEvents.RxError = radioOnRxError;
  Radio.Init(&radioEvents);
  Radio.SetChannel(RADIO_FREQ_HZ);
  Radio.SetTxConfig(MODEM_LORA, RADIO_TX_DBM, 0, RADIO_BW,
                    RADIO_SF, RADIO_CR, 8, false,
                    true, 0, 0, false, 3000);
  Radio.SetRxConfig(MODEM_LORA, RADIO_BW, RADIO_SF, RADIO_CR,
                    0, 8, 0, false, 0, true, 0, 0, false, true);
  Radio.Rx(0);
  radioStarted = true; // configured, not a proof that a remote node exists
  radioNextTxAllowedAt = millis();
  radioNextLocalAt = millis() + 2000 + (esp_random() % 3500);
  Serial.printf("[LORA] configured freq=%lu Hz SF%u BW125kHz node=%08lX\n",
       (unsigned long)RADIO_FREQ_HZ, RADIO_SF, (unsigned long)nodeId);
}

// Shared gate for local reports AND forwarded packets: never send while
// transmitting or during the cooldown after TxDone/TxTimeout.
bool radioCanTransmit(uint32_t now) {
  return radioStarted && !radioTxActive &&
         (int32_t)(now - radioNextTxAllowedAt) >= 0;
}

bool sendLoRaPacket(const char *message, bool isRelay) {
  if (!radioCanTransmit(millis())) return false;
  Radio.Sleep();
  radioTxActive = true;
  radioTxAt = millis();
  Radio.Send((uint8_t *)message, strlen(message));
  radioTxCount++;
  if (isRelay) radioRelayCount++;
  Serial.printf("[LORA] TX %s: %s\n", isRelay ? "relay" : "local", message);
  return true;
}

void pollRadio() {
  if (!radioStarted) return;
  Radio.IrqProcess();
  handleReceivedPacket();
  uint32_t now = millis();
  if (radioTxActive && (uint32_t)(now - radioTxAt) > 4000) {
    Serial.println("[LORA] TX watchdog; return to RX");
    radioTxActive = false;
    radioNextTxAllowedAt = millis() + RADIO_TX_COOLDOWN_MS;
    Radio.Sleep();
    radioNeedsRx = true;
  }
  if (radioNeedsRx && !radioTxActive) {
    Radio.Rx(0);
    radioNeedsRx = false;
  }
  if (!radioCanTransmit(now)) return;
  if (relayPending && (int32_t)(now - relayDueAt) >= 0) {
    char toSend[sizeof(relayPacket)];
    strncpy(toSend, relayPacket, sizeof(toSend));
    toSend[sizeof(toSend) - 1] = '\0';
    if (sendLoRaPacket(toSend, true)) relayPending = false;
    return;
  }
  // Only the backward-compatible Station::begin() auto-transmits.
  // Classroom sketches call station.broadcastTemp() themselves.
  if (legacyAutomatic && (int32_t)(now - radioNextLocalAt) >= 0) {
    radioNextLocalAt = now + RADIO_REPORT_MS + (esp_random() % 1500);
    if (haveReading && !relayPending) {
      const bool good = spiReady && readingValid &&
                        (uint32_t)(now - lastReadingAt) < 5000;
      char packet[110];
      snprintf(packet, sizeof(packet), "T1,%08lX,%08lX,%lu,1,%ld,%ld,%u,%u",
         (unsigned long)nodeId, (unsigned long)bootId, (unsigned long)++packetSeq,
         good ? lroundf(temperatureC * 100.0f) : 0L,
         isfinite(measuredResistanceOhms) ? lroundf(measuredResistanceOhms * 1000.0f) : 0L,
         (unsigned)faultRegister, good ? 1 : 0);
      sendLoRaPacket(packet, false);
    }
  }
}

void drawOLED() {
  if (!oledReady) return;
  const uint32_t now = millis();
  if ((uint32_t)(now - lastOledDrawAt) < 600) return;
  lastOledDrawAt = now;
  oled.clear();
  oled.setTextAlignment(TEXT_ALIGN_LEFT);
  oled.setFont(ArialMT_Plain_10);
  char text[64];
  snprintf(text, sizeof(text), "ST:%s %04lX", stationLabel, (unsigned long)(nodeId & 0xFFFF));
  oled.drawString(0, 0, text);
  snprintf(text, sizeof(text), "AP:%s  WiFi:%u", apReady ? "ON" : "ERR",
           (unsigned)WiFi.softAPgetStationNum());
  oled.drawString(0, 10, text);
  oled.drawString(0, 20, apReady ? WiFi.softAPIP().toString() : "AP unavailable");
  const bool good = spiReady && haveReading && readingValid &&
                    (uint32_t)(now-lastReadingAt) <= 5000;
  if (inExitNodeMode()) {
    oled.drawString(0, 30, "EXIT NODE: LoRa->WiFi");
    snprintf(text, sizeof(text), "Remote sensors: %u", (unsigned)onlinePeerCount());
    oled.drawString(0, 40, text);
  } else {
    snprintf(text, sizeof(text), "LOCAL: %s", good ? "OK" : sensorStatus());
    oled.drawString(0, 30, text);
    if (good) snprintf(text, sizeof(text), "%.2f C  %.2f R", temperatureC, measuredResistanceOhms);
    else snprintf(text, sizeof(text), "FAULT 0x%02X", (unsigned)faultRegister);
    oled.drawString(0, 40, text);
  }
  Peer *displayPeer = nullptr;
  const size_t skip = (now / 4000) % (MAX_PEERS ? MAX_PEERS : 1);
  for (size_t n = 0; n < MAX_PEERS; ++n) {
    Peer &p = peers[(skip + n) % MAX_PEERS];
    if (p.used && (uint32_t)(now - p.seenAt) <= PEER_ONLINE_MS) {
      displayPeer = &p;
      break;
    }
  }
  if (displayPeer) {
    if (displayPeer->valid)
      snprintf(text, sizeof(text), "P:%04lX %.1fC %ddBm",
               (unsigned long)(displayPeer->id & 0xFFFF), displayPeer->temp,
               (int)displayPeer->rssi);
    else
      snprintf(text, sizeof(text), "P:%04lX FAULT 0x%02X",
               (unsigned long)(displayPeer->id & 0xFFFF), displayPeer->fault);
  } else {
    snprintf(text, sizeof(text), "LoRa:%s Peers:%u", radioStarted ? "ON" : "OFF",
             (unsigned)onlinePeerCount());
  }
  // A short student-created message can temporarily replace the last row.
  if (oledMessage.length() && (int32_t)(oledMessageUntil - now) > 0) {
    oled.drawString(0, 50, oledMessage.substring(0, 21));
  } else {
    oled.drawString(0, 50, text);
  }
  oled.display();
}

void initOLED() {
  // Factory test uses Vext power ON (active LOW) before initializing OLED.
  pinMode(Vext, OUTPUT);
  digitalWrite(Vext, LOW);
  delay(100);
  oled.init();
  oled.setFont(ArialMT_Plain_10);
  oled.setTextAlignment(TEXT_ALIGN_LEFT);
  oled.clear();
  oled.drawString(0, 0, "HELTEC V4 PT100");
  oled.drawString(0, 16, "OLED initialized");
  oled.drawString(0, 30, "Starting AP + LoRa...");
  oled.display();
  oledReady = true;
  Serial.println("[OLED] initialized 128x64 I2C display");
}

void handleNodes() {
  // Nodes are only considered online for 45s; expired nodes omitted from API.
  String json = "{\"node_id\":\"" + String(nodeId, HEX) + "\",\"radio_configured\":" +
               String(radioStarted ? "true" : "false") + ",\"tx\":" +
               String(radioTxCount) + ",\"rx\":" + String(radioRxCount) +
               ",\"relayed\":" + String(radioRelayCount) + ",\"peers\":[";
  bool first = true;
  for (auto &p : peers) {
    if (!p.used || (uint32_t)(millis() - p.seenAt) > PEER_RETAIN_MS) continue;
    char item[260];
    snprintf(item, sizeof(item),
             "%s{\"id\":\"%08lX\",\"online\":%s,\"valid\":%s,\"temperature_c\":%.2f,"
             "\"ohms\":%.3f,\"fault\":%u,\"rssi\":%d,\"snr\":%d,\"via_relay\":%s,\"age_s\":%lu}",
             first ? "" : ",", (unsigned long)p.id,
             (uint32_t)(millis() - p.seenAt) <= PEER_ONLINE_MS ? "true" : "false",
             p.valid ? "true" : "false", p.temp, p.ohms, (unsigned)p.fault,
             p.rssi, p.snr, p.relayed ? "true" : "false",
             (unsigned long)((millis()-p.seenAt)/1000));
    json += item;
    first = false;
  }
  json += "]}";
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", json);
}

// Everything is stored locally on the ESP32. No internet connection needed.
// HTML page is in dashboard_html.h (not preprocessed as an Arduino sketch).


void sendCalibrationReply(int status, const char *message) {
  String response = String("{\"message\":\"") + message + "\"}";
  server.sendHeader("Cache-Control", "no-store");
  server.send(status, "application/json", response);
}

void recomputeCompensatedReading() {
  if (!haveReading) return;
  resistanceOhms = measuredResistanceOhms - leadCompensationOhms;
  const bool plausible = resistanceOhms >= 18.0f && resistanceOhms <= 391.0f;
  readingValid = faultRegister == 0 && !rtdFaultFlag && (rawRTD != 0) && plausible;
  temperatureC = readingValid ? pt100Celsius(resistanceOhms) : NAN;
}

void handleCalibrate() {
  if (!haveReading || !spiReady || !readingValid ||
      (uint32_t)(millis() - lastReadingAt) > 5000) {
    sendCalibrationReply(409, "No recent fault-free sensor measurement; cannot calibrate");
    return;
  }
  if (!server.hasArg("reference_c")) {
    sendCalibrationReply(400, "Reference temperature is required");
    return;
  }
  String str = server.arg("reference_c");
  str.trim();
  char *end = nullptr;
  float referenceC = strtof(str.c_str(), &end);
  if (end == str.c_str() || *end != '\0' || !isfinite(referenceC) ||
      referenceC < -50.0f || referenceC > 150.0f) {
    sendCalibrationReply(400, "Enter a valid reference temperature (-50 to 150 C)");
    return;
  }
  const float expectedResistance = pt100ResistanceAtC(referenceC);
  const float proposedOffset = measuredResistanceOhms - expectedResistance;
  if (proposedOffset < 0.0f || proposedOffset > 10.0f) {
    sendCalibrationReply(422, "Offset outside 0-10 ohms: check wiring, Rref, sensor temperature before calibrating");
    return;
  }
  leadCompensationOhms = proposedOffset;
  calibrationStore.putFloat("lead", leadCompensationOhms);
  recomputeCompensatedReading();
  Serial.printf("[CAL] Reference=%.2f C, measured=%.3f ohms, subtracting=%.3f ohms\n",
                referenceC, measuredResistanceOhms, leadCompensationOhms);
  sendCalibrationReply(200, "Calibration saved on Heltec V4. Verify using a second temperature point.");
}

void handleCalibrationReset() {
  leadCompensationOhms = 0.0f;
  calibrationStore.putFloat("lead", leadCompensationOhms);
  recomputeCompensatedReading();
  Serial.println("[CAL] Two-wire compensation reset to 0 ohms");
  sendCalibrationReply(200, "Calibration reset; displaying uncorrected PT100 reading.");
}

void handleStatus() {
  const bool good = readingValid && spiReady && haveReading
                    && (uint32_t)(millis() - lastReadingAt) <= 5000;
  char tempBuf[24] = "null";
  char resistanceBuf[24] = "null";
  char measuredBuf[24] = "null";
  char uncalibratedBuf[24] = "null";
  if (good) {
    snprintf(tempBuf, sizeof(tempBuf), "%.3f", temperatureC);
    snprintf(uncalibratedBuf, sizeof(uncalibratedBuf), "%.3f", uncalibratedTemperatureC);
  }
  if (haveReading) {
    snprintf(resistanceBuf, sizeof(resistanceBuf), "%.3f", resistanceOhms);
    snprintf(measuredBuf, sizeof(measuredBuf), "%.3f", measuredResistanceOhms);
  }

  char body[960];
  snprintf(body, sizeof(body),
           "{\"ok\":%s,\"status\":\"%s\",\"has_sample\":%s,"
           "\"mode\":\"%s\",\"exit_node\":%s,\"sensor_ready\":%s,"
           "\"temperature_c\":%s,\"uncalibrated_temperature_c\":%s,"
           "\"resistance_ohms\":%s,\"measured_resistance_ohms\":%s,"
           "\"compensation_ohms\":%.4f,\"raw\":%u,"
           "\"fault\":%u,\"config\":%u,\"uptime_ms\":%lu,\"sample_ms\":%lu,"
           "\"ap_clients\":%u,\"ap_ip\":\"%s\",\"ap_ssid\":\"%s\"}",
           good ? "true" : "false", sensorStatus(), haveReading ? "true" : "false",
           inExitNodeMode() ? "exit_node" : "sensor_station",
           inExitNodeMode() ? "true" : "false", spiReady ? "true" : "false",
           tempBuf, uncalibratedBuf, resistanceBuf, measuredBuf, leadCompensationOhms, (unsigned)rawRTD,
           (unsigned)faultRegister, (unsigned)lastConfig,
           (unsigned long)millis(), (unsigned long)lastReadingAt,
           (unsigned)WiFi.softAPgetStationNum(), WiFi.softAPIP().toString().c_str(), AP_SSID);
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", body);
}

// Debug output identifies whether requests are actually reaching the device.
void logHTTP(const char *kind) {
  Serial.printf("[HTTP] %s %s | client=%s\n", kind, server.uri().c_str(),
                server.client().remoteIP().toString().c_str());
}

void serveDashboard() {
  logHTTP("dashboard");
  server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  server.send_P(200, "text/html; charset=utf-8", customDashboardHTML ? customDashboardHTML : PAGE);
}

// Operating systems probe these plain-HTTP endpoints after joining a Wi-Fi
// network. Redirecting rather than returning their expected Internet-success
// reply encourages a captive-portal notification or login mini-browser.
void redirectToDashboard() {
  logHTTP("portal redirect");
  server.sendHeader("Location", String("http://") + WiFi.softAPIP().toString() + "/", true);
  server.sendHeader("Cache-Control", "no-store, no-cache, must-revalidate");
  server.send(302, "text/plain; charset=utf-8", "Heltec V4 PT100 dashboard");
}

void handleHealth() {
  char response[220];
  snprintf(response, sizeof(response),
           "{\"http\":true,\"ap_ready\":%s,\"dns_ready\":%s,"
           "\"clients\":%u,\"heap_free\":%u,\"sensor_status\":\"%s\"}",
           apReady ? "true" : "false", dnsReady ? "true" : "false",
           (unsigned)WiFi.softAPgetStationNum(), (unsigned)ESP.getFreeHeap(), sensorStatus());
  logHTTP("health");
  server.sendHeader("Cache-Control", "no-store");
  server.send(200, "application/json", response);
}

void setupHTTPRoutes() {
  server.on("/", HTTP_GET, serveDashboard);
  server.on("/api/status", HTTP_GET, handleStatus);
  server.on("/api/nodes", HTTP_GET, handleNodes);
  server.on("/api/calibrate", HTTP_POST, handleCalibrate);
  server.on("/api/calibration/reset", HTTP_POST, handleCalibrationReset);
  server.on("/api/health", HTTP_GET, handleHealth);
  server.on("/favicon.ico", HTTP_GET, []() { server.send(204); });

  // Android / ChromeOS
  server.on("/generate_204", HTTP_GET, redirectToDashboard);
  server.on("/gen_204", HTTP_GET, redirectToDashboard);
  // Apple iOS / macOS
  server.on("/hotspot-detect.html", HTTP_GET, redirectToDashboard);
  server.on("/library/test/success.html", HTTP_GET, redirectToDashboard);
  // Windows
  server.on("/connecttest.txt", HTTP_GET, redirectToDashboard);
  server.on("/ncsi.txt", HTTP_GET, redirectToDashboard);
  // Firefox, Linux and generic captive-portal checks
  server.on("/canonical.html", HTTP_GET, redirectToDashboard);
  server.on("/success.txt", HTTP_GET, redirectToDashboard);
  server.on("/redirect", HTTP_GET, redirectToDashboard);

  // All other HTTP paths on any DNS name redirect to the local dashboard.
  // Never accidentally return the OS's Internet-success payload.
  server.onNotFound(redirectToDashboard);
}

// Uprooted's nodes get unique radio IDs and AP SSIDs automatically.
// Students do not need to invent a station name.
void Station::beginBoard(bool enableRelay) {
  beginBoard("UPROOTED", enableRelay);
}

void Station::beginBoard(const char *name, bool enableRelay) {
  if (classroomInitialized) return;
  // Sanitize station name for the SSID and OLED; avoid personal student data.
  size_t count = 0;
  if (name) {
    for (size_t i = 0; name[i] && count < sizeof(stationLabel)-1; ++i) {
      const unsigned char ch = (unsigned char)name[i];
      if (isalnum(ch)) stationLabel[count++] = (char)toupper(ch);
      else if (ch == '-' || ch == '_') stationLabel[count++] = '-';
    }
  }
  if (!count) memcpy(stationLabel, "ROOM", 5);
  else stationLabel[count] = '\0';
  relayAllowed = enableRelay;
  Serial.begin(115200);
  delay(300);
  Serial.println("\n=== CLASSROOM HELTEC V4 PT100 STATION ===");
  Mcu.begin(HELTEC_BOARD, SLOW_CLK_TPYE);
  nodeId = (uint32_t)(ESP.getEfuseMac() & 0xFFFFFFFFULL);
  bootId = esp_random();
  snprintf(AP_SSID, sizeof(AP_SSID), "PT100-%s-%04lX", stationLabel,
           (unsigned long)(nodeId & 0xFFFF));
  classroomInitialized = true;
  initOLED();
  Serial.printf("[BOARD] team=%s node=%08lX\n", stationLabel,
                (unsigned long)nodeId);
}

bool Station::setupPT100() {
  if (!classroomInitialized) {
    Serial.println("[PT100] Call beginBoard() first");
    return false;
  }
  if (sensorInitialized) return spiReady;
  sensorInitialized = true;
  calibrationStore.begin("pt100-cal", false);
  leadCompensationOhms = calibrationStore.getFloat("lead", 0.0f);
  if (!isfinite(leadCompensationOhms) || leadCompensationOhms < 0.0f ||
      leadCompensationOhms > 10.0f) leadCompensationOhms = 0.0f;
  Serial.printf("[CAL] Two-wire compensation: %.3f ohms\n", leadCompensationOhms);
  pinMode(PIN_CS, OUTPUT);
  digitalWrite(PIN_CS, HIGH);
  sensorBus.begin(PIN_SCK, PIN_MISO, PIN_MOSI, PIN_CS);
  Serial.printf("[PT100] SPI SCK=%d MISO=%d MOSI=%d CS=%d\n",
                PIN_SCK, PIN_MISO, PIN_MOSI, PIN_CS);
  const bool ok = initializeSensor();
  lastProbeAt = millis();
  if (!ok) Serial.println("[ROLE] EXIT NODE: local MAX31865 unavailable; listening for remote LoRa sensor data");
  return ok;
}

bool Station::setupLoRa() {
  if (!classroomInitialized) {
    Serial.println("[LORA] Call beginBoard() first");
    return false;
  }
  if (radioStarted) return true;
  // LoRa antenna must be attached before calling setupLoRa().
  initRadio();
  return radioStarted;
}

bool Station::setupAP(const char *password, const char *studentHTML) {
  if (!studentHTML || studentHTML[0] == '\0') {
    Serial.println("[HTTP] ERROR: provide a nonempty website.h HTML page");
    return false;
  }
  if (apReady) {
    Serial.println("[HTTP] Set custom HTML before starting the access point");
    return false;
  }
  customDashboardHTML = studentHTML;
  return setupAP(password);
}

bool Station::setupAP(const char *password) {
  if (!classroomInitialized) {
    Serial.println("[WIFI] Call beginBoard() first");
    return false;
  }
  if (apReady) return true;
  if (!password || strlen(password) < 8 || strlen(password) > 63) {
    Serial.println("[WIFI] AP password must have 8 to 63 characters");
    return false;
  }
  strncpy(classroomPassword, password, sizeof(classroomPassword)-1);
  classroomPassword[sizeof(classroomPassword)-1] = '\0';
  WiFi.mode(WIFI_AP);
  const bool configOK = WiFi.softAPConfig(AP_IP, AP_IP, AP_SUBNET);
  Serial.printf("[WIFI] static IP config: %s\n", configOK ? "OK" : "FAILED");
  // 2.4GHz, visible, channel 1, max 4 clients.
  apReady = WiFi.softAP(AP_SSID, AP_PASSWORD, 1, 0, 4);
  if (!apReady) {
    Serial.println("[WIFI] ERROR: AP did not start");
    return false;
  }
  Serial.printf("[WIFI] AP started: %s\n", AP_SSID);
  Serial.printf("[WIFI] AP IP: %s\n", WiFi.softAPIP().toString().c_str());
  dnsReady = dnsServer.start(DNS_PORT, "*", WiFi.softAPIP());
  Serial.printf("[DNS] captive portal: %s\n", dnsReady ? "READY" : "FAILED");
  if (!apRoutesRegistered) {
    setupHTTPRoutes();
    apRoutesRegistered = true;
  }
  server.begin();
  Serial.println("[HTTP] Dashboard: http://192.168.4.1/");
  Serial.println("[HTTP] API: http://192.168.4.1/api/status");
  return true;
}

void Station::readTemp() {
  if (!sensorInitialized) return;
  pollSensor(); // returns immediately; called often to advance conversion
}

bool Station::broadcastTemp() {
  // Broadcast only if a sensor conversion has finished and radio is free.
  // Invalid readings are broadcast as faults rather than fake temperatures.
  if (!radioCanTransmit(millis()) || relayPending || !haveReading) return false;
  const bool good = spiReady && readingValid &&
                    (uint32_t)(millis() - lastReadingAt) <= 5000;
  const long centi = good ? lroundf(temperatureC * 100.0f) : 0L;
  const long milli = isfinite(measuredResistanceOhms)
                    ? lroundf(measuredResistanceOhms * 1000.0f) : 0L;
  char packet[110];
  snprintf(packet, sizeof(packet), "T1,%08lX,%08lX,%lu,1,%ld,%ld,%u,%u",
           (unsigned long)nodeId, (unsigned long)bootId,
           (unsigned long)++packetSeq, centi, milli,
           (unsigned)faultRegister, good ? 1 : 0);
  sendLoRaPacket(packet, false);
  return true;
}

// Existing sketches can still initialize everything in one call.
bool Station::begin(const char *name, const char *password, bool enableRelay) {
  beginBoard(name, enableRelay);
  setupPT100();
  setupLoRa();
  const bool wifiOK = setupAP(password);
  legacyAutomatic = true;
  return wifiOK;
}

void Station::update() {
  if (apReady) {
    // Required on older arduino-esp32; harmless on newer async DNSServer.
    dnsServer.processNextRequest();
    server.handleClient();
  }
  if (legacyAutomatic && sensorInitialized) pollSensor();
  pollRadio();
  drawOLED();
  if (apReady && (uint32_t)(millis() - lastNetworkReportAt) >= 10000) {
    lastNetworkReportAt = millis();
    Serial.printf("[WIFI] clients=%u IP=%s free_heap=%u sensor=%s\n",
                  (unsigned)WiFi.softAPgetStationNum(),
                  WiFi.softAPIP().toString().c_str(),
                  (unsigned)ESP.getFreeHeap(), sensorStatus());
  }
  delay(2);
}


Reading Station::local() const {
  Reading r{};
  r.hasSample = haveReading;
  r.valid = spiReady && haveReading && readingValid &&
            (uint32_t)(millis() - lastReadingAt) <= 5000;
  r.temperatureC = r.valid ? temperatureC : NAN;
  r.resistanceOhms = haveReading ? measuredResistanceOhms : NAN;
  r.compensationOhms = leadCompensationOhms;
  r.fault = faultRegister;
  r.raw = rawRTD;
  r.ageMs = haveReading ? (uint32_t)(millis() - lastReadingAt) : UINT32_MAX;
  return r;
}

size_t Station::peerCount() const { return onlinePeerCount(); }

bool Station::peer(size_t index, RemoteReading &out) const {
  size_t seen = 0;
  for (const auto &p : peers) {
    if (!p.used || (uint32_t)(millis() - p.seenAt) > PEER_ONLINE_MS) continue;
    if (seen++ != index) continue;
    out.id = p.id;
    out.valid = p.valid;
    out.temperatureC = p.valid ? p.temp : NAN;
    out.resistanceOhms = p.ohms;
    out.fault = p.fault;
    out.rssi = p.rssi;
    out.ageMs = (uint32_t)(millis() - p.seenAt);
    return true;
  }
  return false;
}

String Station::wifiName() const { return String(AP_SSID); }
IPAddress Station::wifiIP() const { return WiFi.softAPIP(); }
bool Station::wifiReady() const { return apReady; }
bool Station::radioReady() const { return radioStarted; }
bool Station::exitNodeMode() const { return inExitNodeMode(); }
uint32_t Station::nodeID() const { return nodeId; }

void Station::showMessage(const String &text, uint32_t durationMs) {
  oledMessage = text;
  oledMessageUntil = millis() + durationMs;
  lastOledDrawAt = 0;
}

} // namespace HeltecPT100Kit
