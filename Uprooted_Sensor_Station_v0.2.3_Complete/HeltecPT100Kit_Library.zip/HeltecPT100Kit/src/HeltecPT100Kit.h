#pragma once
#include <Arduino.h>
#include <IPAddress.h>

// Student-friendly interface for the Heltec V4 + MAX31865 temperature station.
// Hardware driver, OLED, access point, captive portal and LoRa live in .cpp.
namespace HeltecPT100Kit {

struct Reading {
  bool valid;               // true only for a recent fault-free sensor sample
  bool hasSample;           // a conversion has occurred
  float temperatureC;      // NAN when invalid
  float resistanceOhms;    // raw, uncorrected measured RTD resistance
  float compensationOhms;  // stored 2-wire lead compensation
  uint8_t fault;            // MAX31865 fault bits, 0 means no fault
  uint16_t raw;             // MAX31865 15-bit ADC value
  uint32_t ageMs;           // age of last sample in milliseconds
};

struct RemoteReading {
  uint32_t id;              // unique remote node ID
  bool valid;
  float temperatureC;      // NAN when invalid
  float resistanceOhms;
  uint8_t fault;
  int16_t rssi;             // received signal strength in dBm
  uint32_t ageMs;
};

class Station {
public:
  // NEW classroom API. Each lesson starts one piece of the station.
  // Call beginBoard() first in Arduino setup(), then the three setup steps.
  // Only one Station per board is supported.
  void beginBoard(const char* stationName, bool enableRelay = true); // Legacy naming API
  void beginBoard(bool enableRelay = true); // Uprooted classroom default; no station name needed
  bool setupPT100();                // Starts MAX31865 hardware and 2-wire PT100
  bool setupLoRa();                 // Starts SX1262 raw LoRa radio (antenna required)
  bool setupAP(const char* password); // Default library dashboard (legacy)
  // Student-provided HTML: pass a static PROGMEM string from website.h.
  // The library still serves /api/status and /api/nodes.
  bool setupAP(const char* password, const char* studentHTML);

  // Call these from STUDENT-defined readTemp() / broadcastTemp() functions.
  // readTemp() advances non-blocking conversion (call every loop).
  void readTemp();
  // broadcastTemp() sends most recent local reading once; returns false if
  // the radio is busy or no sensor sample exists. Student controls interval.
  bool broadcastTemp();

  // update() services captive portal, OLED, received packets and relays.
  // Do not block this with long delay() calls.
  void update();

  // Backward-compatible one-call start for existing teacher projects.
  // This legacy path retains automatic sensor sampling and broadcasts.
  bool begin(const char* stationName, const char* wifiPassword,
             bool enableRelay = true);

  Reading local() const;
  size_t peerCount() const;
  bool peer(size_t index, RemoteReading &out) const;
  String wifiName() const;
  IPAddress wifiIP() const;
  bool wifiReady() const;
  bool radioReady() const;
  bool exitNodeMode() const; // True if no working MAX31865; remote LoRa stays active.
  uint32_t nodeID() const;
  void showMessage(const String &text, uint32_t durationMs = 3000);
};

} // namespace HeltecPT100Kit
